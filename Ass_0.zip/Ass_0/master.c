#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include<unistd.h>

#define SHMSZ     27

int main(){
	int status;
	char c;
    int shmid,c1;
    key_t key;
    char *shm, *s;
    char input_str[30];
    int mcpipe1[2];
    
    if (c1 = pipe(mcpipe1)){
    	perror("unable to create the first pipe");
    	exit(1);
  	}
    key = 5678;

    if ((shmid = shmget(key, SHMSZ, IPC_CREAT | 0666)) < 0) {
        perror("shmget");
        exit(1);
    }
    if ((shm = shmat(shmid, NULL, 0)) == (void *) -1) {
        perror("shmat");
        exit(1);
    }
	pid_t ChildOne=fork();
	if(ChildOne==-1){
		perror("ChildOne was not initialized");
		exit(1);
	}
	else if(ChildOne==0){
		printf("ChildOne was created successfully - PID:%d\n", getpid());
		close(mcpipe1[0]);
		execl("child_pgm","child_pgm,mc0,mc1",NULL);
		perror("ChildOne exec failed");
		exit(1);
	}
	pid_t ChildTwo=fork()
	if(ChildTwo == -1){
		perror("ChildTwo was not initialized");
		exit(1);
		}
	else if(ChildTwo == 0){
		printf("ChildTwo was created successfully - PID:%d\n", getpid());
		close(mcpipe1[0]);
		execl("child_pgm","child_pgm,cc0,cc1,",NULL);
		perror("ChildTwo exec failed");
		exit(1);	
		}
	}
	FILE* output_file = fopen("assignment_zero_output.txt", "a");
	close(mcpipe1[0]);
  	if(write(mcpipe1[1], (void *)&key, sizeof(key_t)) == -1){
  		perror("Error writing to the pipe");
	 	exit(1);
	 }
	while(1){
		fgets(input_str, sizeof(input_str), stdin);
		s=shm;
		sprintf(shm,"Parent: %s",input_str);
		if (strncmp(input_str, "TERMINATE", 9) == 0) {
            close(mcpipe1[1]);
            close(mcpipe2[1]);
            wait(NULL);
            wait(NULL);
            fclose(output_file);
            break;
        }
	}
}
}

	
	wait(&status);
