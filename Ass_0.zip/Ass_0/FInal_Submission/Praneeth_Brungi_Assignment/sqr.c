/*
Written by Shivakant Mishra
Last update: September 18, 2017
*/


#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#define MAX_LINE 256

void printVirtualMemoryLayout() {
    char buffer[MAX_LINE];
    char path[MAX_LINE];
    snprintf(path, sizeof(path), "/proc/%d/maps", getpid());

    // Open the /proc/[PID]/maps file for the current process
    FILE* fp = fopen(path, "r");
    if (fp == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    // Read and print each line of the maps file
    while (fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }

    // Close the file
    fclose(fp);
}
int main(int argc, char *argv[])

{
  int i, c1, max = 100, status;
  FILE *fd;

  fd = fopen("squares", "w");
  for (i = 0; i < max; i++) {
    fprintf(fd, "%d\n", i * i);
  }
  fclose(fd);
  printf("Child Process after exec\n");  
  printVirtualMemoryLayout();  
}

