#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <string.h>
#include <semaphore.h>

int main(int argc,char* argv[]){
   int mcpipe1[2],terminate=0;
   key_t key;
   char *ChildName = argv[1],temp[16];
   //strcpy(temp,ChildName);
   //strcat(temp,":");
   sem_t *sem1,*sem2,*sem3;
   sem1=sem_open("/my_semaphore1",0);
   sem2=sem_open("/my_semaphore2",0);
   sem3=sem_open("/my_semaphore3",0);
   mcpipe1[0]=atoi(argv[2]);
   mcpipe1[1]=atoi(argv[3]);
   read(mcpipe1[0],&key,sizeof(key_t));
   printf("%s\n",ChildName);

   FILE *outputFile = fopen("assignment_zero_output.txt", "a");
   if (outputFile == NULL) {
      perror("fopen");
         exit(1);
      }  
   int id = shmget(key,sizeof(int),0666);
   if(id == -1){
       perror("Shared memory attachment failed");
      exit(1);
   } 
   char *shm=(char *)shmat(id,NULL,0);
   if(shm == (int *)-1){
      perror("shared memory attachment failed");
      exit(1);
   }
   char input[512];
   strcpy(input, shm);
   //strcat(temp,input);
   fprintf(outputFile,"%s",input);
   printf("Enter string %s:",ChildName);
   fgets(input,sizeof(input),stdin);
   //scanf("%s",input);
   if (strcmp(input, "TERMINATE") == 0) {
      shmdt(shm);
      fclose(outputFile);         
      exit(0);
      }
   strcat(shm,input);
   if(strcmp(ChildName,"ChildOne") == 0){
      sem_post(sem3);
   }
   else{
      sem_post(sem1);
   }


         
   //printf("%s",shm);
    /*mcpipe1[0]=atoi(argv[3]);
    mcpipe1[1]=atoi(argv[4]);
    key_t key;
    printf("hi child/n");
    char *ChildName=argv[1];
     if(read(mcpipe1[0],&key,sizeof(key_t)) == -1){
        perror("error reading from the pipe");
        exit(1);
     }
     int id = shmget(key,sizeof(int),0666);
     if(id == -1){
        perror("Shared memory attachment failed");
        exit(1);
     }

      char *shm=(char *)shmat(id,NULL,0);
      if(shm == (int *)-1){
         perror("shared memory attachment failed");
         exit(1);
      }
      int sem_id;
      if ((sem_id = semget(IPC_PRIVATE, 3, 0666)) == -1) {
         perror("semget");
         exit(1);
      }


       FILE *outputFile = fopen("assignment_zero_output", "a");
        if (outputFile == NULL) {
            perror("fopen");
            exit(1);
        }
      while(!terminate){
         char input[512];
         strcpy(input, shm);
         strcat(input,ChildName);
         fprintf(outputFile,"%s",input);
         printf("Enter string %s\n",ChildName);
         scanf("%s",input);
         if (strcmp(input, "TERMINATE\n") == 0) {
            shmdt(shm);
            fclose(outputFile);
            terminate=1;
            exit(0);
         }
         strcat(shm,input);



      } 
    

     if(shmdt(shm) == -1){
        perror("Shared Memory Detachment Failed");
        exit(1);
     }*/
     return 0;
}