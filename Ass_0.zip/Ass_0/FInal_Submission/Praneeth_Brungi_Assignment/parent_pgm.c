#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>
#include <signal.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <semaphore.h>

#define SHMSZ     27

int main(){
    int mcpipe[2],shmid,terminate=0;
    char mc1[10],mc2[10];
    key_t key = 5678;
    pid_t ChildOnepid,ChildTwopid;
    char *shm, *s;
    sem_t *sem1,*sem2,*sem3;
    //sem1 = sem_open("/semaphore1", O_CREAT,  0666, 0);
    //sem_init(sem1, 0, 0);
    //sem_init(sem2,0,0);
    //sem_init(sem3,0,0);
    sem1 = sem_open("/my_semaphore1", O_CREAT, 0644, 0);
    sem2 = sem_open("/my_semaphore2", O_CREAT, 0644, 1);
    sem3 = sem_open("/my_semaphore3", O_CREAT, 0644, 0);
    //sem2 = sem_open("/semaphore2", O_CREAT,  0666, 1);
    //sem3 = sem_open("/semaphore3", O_CREAT,  0666, 0);
    if ((shmid = shmget(key, SHMSZ, IPC_CREAT | 0666)) < 0) {
        perror("shmget");
        exit(1);
    }
    if ((shm = shmat(shmid, NULL, 0)) == (void *) -1) {
        perror("shmat");
        exit(1);
    }
    FILE *outputFile = fopen("assignment_zero_output.txt", "w");
    if (outputFile == NULL) {
        perror("fopen");
        exit(1);
    }
    char input[512],input2[512];
    printf("Parent 1:");
    fgets(input,sizeof(input),stdin);
    strcat(shm,input);
    if (pipe(mcpipe) == -1) {                                                 
        perror("unable to create the first pipe");
        exit(1);
    }
    sprintf(mc1,"%d",mcpipe[0]);
    sprintf(mc2,"%d",mcpipe[1]);
    pid_t child1_pid=fork();
    if(child1_pid == -1){
        perror("Child one was not forked");
        exit(1);
    }
    else if(child1_pid == 0){
        while(1){
            ChildOnepid=getpid();
            sem_wait(sem2);
            execl("child_pgm","child_pgm","ChildOne",mc1,mc2,NULL);
        }
        
    }

    pid_t child2_pid=fork();
    if(child2_pid == -1){
        perror("Child Two was not forked");
        exit(1);
    }
    else if(child2_pid == 0){
        while(1){
            ChildTwopid=getpid();
            sem_wait(sem3);
            execl("child_pgm","child_pgm","ChildTwo",mc1,mc2,NULL); 
        }
    }
    close(mcpipe[0]);
    if(write(mcpipe[1],(void *)&key,sizeof(key_t)) == -1){
        perror("Error writing to the pipe");
        exit(1);
    }
    while(!terminate){
    sem_wait(sem1);
    strcpy(input2, shm);
    strcat(input2,"Parent");
    fprintf(outputFile,"%s",input2);
    printf("Parent 2:");
    //scanf("%s",input2);
    fgets(input2,sizeof(input2),stdin);
    strcat(shm,input2);
    if (strcmp(input2, "TERMINATE") == 0) {
        shmdt(shm);
        shmctl(shmid, IPC_RMID, NULL);
        kill(ChildOnepid, SIGTERM);
        kill(ChildTwopid, SIGTERM);
        fclose(outputFile);
        sem_close(sem1);
        sem_unlink("/my_semaphore1");
        sem_close(sem2);
        sem_unlink("/my_semaphore2");
        sem_close(sem3);
        sem_unlink("/my_semaphore3");
            //semctl(semid, 0, IPC_RMID, 0);
        exit(0);
        }
    sem_post(sem2);
    sem_post(sem3);
    //printf("hi\n");
    }
    
    //sem_post(sem2);
    //printf("%d\n",getpid());
    wait(NULL);
    wait(NULL);
    shmdt(shm);
    shmctl(shmid, IPC_RMID, NULL);
    kill(ChildOnepid,SIGTERM);
    kill(ChildTwopid,SIGTERM);
    sem_close(sem1);
    sem_unlink("/semaphore1");
    sem_close(sem2);
    sem_unlink("/semaphore2");
    sem_close(sem3);
    sem_unlink("/semaphore3");
    
}