#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_LINE 256

void printVirtualMemoryLayout() {
    char buffer[MAX_LINE];
    char path[MAX_LINE];
    snprintf(path, sizeof(path), "/proc/%d/maps", getpid());

    FILE* fp = fopen(path, "r");
    if (fp == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }
    while (fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    fclose(fp);
}

void foo() {
    pid_t child_pid = fork();
    
    if (child_pid == -1) {
        perror("fork");
        exit(1);
    }
    
    if (child_pid == 0) {
        printf("Child process:\n");
        printf("Child PID: %d\n", getpid());
        printf("Child Memory Layout Before exec():\n");
        printVirtualMemoryLayout();
        execl("sqr","sqr",NULL);
        printVirtualMemoryLayout();
        printf("Child: Virtual memory layout is different from parent\n");
        //execl(strcat("/usr/bin/ls",mypid),NULL);
        perror("exec");
        exit(1);
    } else {
        printf("Parent Process\n");
        printVirtualMemoryLayout();
    }
    wait(NULL);
}

int main() {
    foo();
    return 0;
}

