#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <sys/sem.h>

#define SHM_SIZE 1024

struct SharedData {
    char message[SHM_SIZE];
    int terminate;
};

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <ChildName>\n", argv[0]);
        return 1;
    }

    char *child_name = argv[1];

    // Attach to the existing shared memory segment
    int shmid = shmget(1234, sizeof(struct SharedData), 0666);
    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }

    struct SharedData *shared_data = shmat(shmid, NULL, 0);
    if (shared_data == (void *)-1) {
        perror("shmat");
        exit(1);
    }

    while (1) {
        // Wait for Parent to signal that it has written to shared memory
        while (semctl(semid, 0, GETVAL) == 1)
            usleep(10000);  // Sleep for 10ms

        // Read from shared memory
        printf("%s: %s", child_name, shared_data->message);

        // Check for termination condition
        if (shared_data->terminate)
            break;

        // Prompt for user input
        printf("%s: Enter a string:\n", child_name);
        fgets(shared_data->message, SHM_SIZE, stdin);

        // Prefix the message and write to shared memory
        snprintf(shared_data->message, SHM_SIZE, "%s: %s", child_name, shared_data->message);
        
        // Signal Parent to read from shared memory
        semctl(semid, 0, SETVAL, 0);
    }

    // Detach from shared memory
    shmdt(shared_data);

    printf("%s: Exiting.\n", child_name);
    return 0;
}
