#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    // Create a child process
    pid_t child_pid = fork();

    if (child_pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (child_pid == 0) {
        // This is the child process

        // Execute pmap before declaring the integer variable
        printf("vmmap before int declaration:\n");
        execl("/usr/bin/pmap", "pmap", "-x", itoa(getpid()), NULL);
        perror("execl");
        exit(EXIT_FAILURE);
    } else {
        // This is the parent process

        // Wait for the child process to finish executing pmap
        wait(NULL);

        // Declare an integer variable
        int x = 42;

        // Execute pmap after declaring the integer variable
        printf("\nvmmap after int declaration:\n");
        execl("/usr/bin/pmap", "pmap", "-x", itoa(getpid()), NULL);
        perror("execl");
        exit(EXIT_FAILURE);
    }

    return 0;
}
