#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
void foo() {
    pid_t child_pid = fork();
    
    if (child_pid == -1) {
        perror("fork");
        exit(1);
    }
    
    if (child_pid == 0) {
        // This is the child process.
        printf("Child process:\n");
        printf("Child PID: %d\n", getpid());
        //int pid = getpid();
        //char * mypid = malloc(6);   
        //sprintf(mypid, "%d", pid);
        //strcat("/usr/bin/vmmap",mypid);
        execl("usr/bin/ls",NULL);
        printf("Child Memory Layout Before exec():\n");
        //execl("sqr","sqr",NULL);
        printf("Child: Virtual memory layout is different from parent\n");
        //execl(strcat("/usr/bin/ls",mypid),NULL);
        perror("exec");
        exit(1);
    } else {
        int pid = getpid();
        char * mypid = malloc(6);   // ex. 34567
        sprintf(mypid, "%d", pid);
        execl(strcat("/usr/bin/vmap",mypid),NULL);
    }
}

int main() {
    foo();
    return 0;
}
