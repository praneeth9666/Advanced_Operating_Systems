#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void foo() {
    pid_t child_pid = fork();
    
    if (child_pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }
    
    if (child_pid == 0) {
        // This is the child process.
        printf("Child process:\n");
        printf("Child PID: %d\n", getpid());
        // Before calling exec(), let's observe the virtual memory layout.
        execl("/usr/bin/vmmap %d",getpid());
        printf("Child Memory Layout Before exec():\n");
        // You can use tools like /proc/self/maps to observe the memory layout.
        // For simplicity, we'll just print a message here.
        execl("sqr","sqr",NULL);
        printf("Child: Virtual memory layout is different from parent\n");
        int pid = getpid();
    char * mypid = malloc(6);   // ex. 34567
    sprintf(mypid, "%d", pid);
    char command[50];
    strcpy( command, "vmmap" );
    strconcat(command,mypid);
    system(command);
        // Now, we'll execute another C program using exec.
        char *args[] = {"/path/to/your/other_program", NULL};
        execv(args[0], args);
        
        // If exec fails, print an error message.
        perror("exec");
        exit(EXIT_FAILURE);
    } else {
        // This is the parent process.
        printf("Parent process:\n");
        printf("Parent PID: %d\n", getpid());
        printf("Parent Memory Layout:\n");
        // You can use tools like /proc/self/maps to observe the memory layout.
        // For simplicity, we'll just print a message here.
        printf("Parent: Virtual memory layout may be different from child\n");
    }
}

int main() {
    foo();
    return 0;
}
