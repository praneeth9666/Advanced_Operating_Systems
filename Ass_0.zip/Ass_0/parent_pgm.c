#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include<signal.h>

#define SHM_SIZE 1024

int main() {
    int pid1, pid2;
    int shmid;
    char *shm_ptr;
    char process_names[2][20] = {"ChildOne", "ChildTwo"};
    int pipefd[2];

    // Create a shared memory segment
    shmid = shmget(IPC_PRIVATE, SHM_SIZE, IPC_CREAT | 0666);
    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }

    // Attach shared memory to parent process
    shm_ptr = shmat(shmid, NULL, 0);
    if (shm_ptr == (char *)-1) {
        perror("shmat");
        exit(1);
    }

    // Create a pipe for communicating the shared memory key to child processes
    if (pipe(pipefd) == -1) {
        perror("pipe");
        exit(1);
    }

    // Create ChildOne process
    if ((pid1 = fork()) == 0) {
        // ChildOne process
        close(pipefd[1]); // Close write end of pipe
        close(pipefd[0]); // Close unused read end of pipe

        // Set up arguments for exec
        char shmid_str[32];
        sprintf(shmid_str, "%d", shmid);
        char *args[] = {"child_pgm", process_names[0], shmid_str, NULL};

        // Execute child program
        execvp("./child_pgm", args);
        perror("execvp");
        exit(1);
    } else if (pid1 == -1) {
        perror("fork");
        exit(1);
    }

    // Create ChildTwo process
    if ((pid2 = fork()) == 0) {
        // ChildTwo process
        close(pipefd[1]); // Close write end of pipe
        close(pipefd[0]); // Close unused read end of pipe

        // Set up arguments for exec
        char shmid_str[32];
        sprintf(shmid_str, "%d", shmid);
        char *args[] = {"child_pgm", process_names[1], shmid_str, NULL};

        // Execute child program
        execvp("./child_pgm", args);
        perror("execvp");
        exit(1);
    } else if (pid2 == -1) {
        perror("fork");
        exit(1);
    }

    close(pipefd[0]); // Close read end of pipe

    // Parent process
    FILE *output_file = fopen("assignment_zero_output.txt", "w");
    if (!output_file) {
        perror("fopen");
        exit(1);
    }

    // Read input from the terminal and communicate with child processes
    char input[100];
    while (1) {
        printf("Input: ");
        fgets(input, sizeof(input), stdin);

        // Write input to shared memory
        strcpy(shm_ptr, input);

        // Notify ChildOne to read from shared memory
        write(pipefd[1], process_names[0], strlen(process_names[0]) + 1);

        // Wait for ChildOne to complete its task
        read(pipefd[1], input, sizeof(input));

        // Write ChildOne's output to the file
        fprintf(output_file, "ChildOne: %s", input);

        // Notify ChildTwo to read from shared memory
        write(pipefd[1], process_names[1], strlen(process_names[1]) + 1);

        // Wait for ChildTwo to complete its task
        read(pipefd[1], input, sizeof(input));

        // Write ChildTwo's output to the file
        fprintf(output_file, "ChildTwo: %s", input);

        // Check if input is "TERMINATE"
        if (strcmp(input, "TERMINATE\n") == 0) {
            break;
        }
    }

    fclose(output_file);

    // Kill ChildOne and ChildTwo
    kill(pid1, SIGKILL);
    kill(pid2, SIGKILL);

    // Close shared memory
    shmdt(shm_ptr);
    shmctl(shmid, IPC_RMID, NULL);

    return 0;
}
