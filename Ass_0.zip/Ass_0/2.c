#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#define _GNU_SOURCE
#include <assert.h>

int global_var;

int segments(){
	static int local_stat_var;
	int local_var=5;
	int local_var_2=8;
	printf("data/static:%p\n",&global_var);
	printf("data/static:%p\n",&local_stat_var);
	printf("stack:%p\n",&local_var);
	printf("stack2:%p\n",&local_var_2);
	printf("text:%p\n",&segments);

	void *b1 = sbrk(0); //start of heap
	printf("Heap start address: \t%p\n", b1);
	int *p = (int *)malloc(1);

    void *b2 = sbrk(0); 
    printf("Heap top address after first malloc: \t%p\n", p);

    int *r = (int *)malloc(100);

    void *b4 = sbrk(0);
    printf("Heap top address after second malloc: \t%p\n", r);

    void* mmap_region = mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    printf("Address of mmap_region (mmap memory): %p\n", mmap_region);

    printf("Page size (getpagesize) %d\n", getpagesize());

    struct rlimit x;
    getrlimit(RLIMIT_AS, &x);
    printf("Current maximum size of this process virtual address space = %llu\n", x.rlim_max);
    //printf("Size of process' virtual address space: %lu bytes\n", (unsigned long)(-1));
	return 0;

}
int main(int argc,char* argv[]){
	printf("main:%p\n",main);
	printf("argc:%p\n",&argc);
	printf("argv:%p\n",argv);
	segments();
	return 0;
}