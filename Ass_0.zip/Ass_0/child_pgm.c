#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ipc.h>
#define SHMSZ     27

main(int argc, char *argv[])

{
  int mcpipe1[2];
  int shmid;
  key_t key;
  char *shm, *s;

  //close(mcpipe1[1]);
  
  read(mcpipe1[0], (char *)&key, sizeof(key_t));
  
  if ((shmid = shmget(key, SHMSZ, 0666)) < 0) {
        perror("shmget");
        exit(1);
    }

  if ((shm = shmat(shmid, NULL, 0)) == (void *) -1) {
        perror("shmat");
        exit(1);
    }
  for (s = shm; *s != '\0'; s++){
    putchar(*s);
    printf("hi\n");
  }

  putchar('\n');  
}

