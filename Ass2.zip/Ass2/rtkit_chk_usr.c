#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define LOG_FILE "/var/log/syslog"  // Change this to your system's log file
#define LKM_PATH "rootkit.ko"  // Replace with the actual path to your LKM

int main() {
    FILE *logFile = fopen(LOG_FILE, "r");
    if (logFile == NULL) {
        perror("Failed to open log file");
        return 1;
    }

    char *syscallName = "rtkit_chk";  // The name of the system call to filter
    char buffer[1024];

    // Load the LKM
    if (system("sudo insmod " LKM_PATH) != 0) {
        perror("Failed to load LKM");
        return 1;
    }

    while (1) {
        while (fgets(buffer, sizeof(buffer), logFile) != NULL) {
            if (strstr(buffer, syscallName) != NULL) {
                printf("%s", buffer);
            }
        }

        // You can add a delay here to control the polling frequency
        usleep(1000000);  // Sleep for 1 second
        rewind(logFile);
    }

    // Unload the LKM
    if (system("sudo rmmod your_lkm") != 0) {
        perror("Failed to unload LKM");
        return 1;
    }

    fclose(logFile);
    return 0;
}
