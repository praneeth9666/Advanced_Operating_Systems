#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/syscall.h>

int main() {
    printf("%ld\n", syscall(__NR_nfsservctl,0));
    return EXIT_SUCCESS;
}